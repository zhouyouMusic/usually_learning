#include <stdio.h>
#include <stdlib.h>
#include "voiceInterface.h"
#include "alsaInterface.h"


static void micShortToFloat(short *input,float *output,float *aec,int nMics,int length) {
	
	int k = 0;
	int j = 0;
	//        int length = (FRAME_LEN << 1);
	float *aec2 = aec + 1024;
	for (k = 0; k < length;k++) {
		output[k] = input[8 + 12 * k] * 0.00003052f;
		aec[k] = input[10 + 12 * k] * 0.00003052f;
		aec2[k] = input[11 + 12 * k] * 0.00003052f;
	}
	for (; j < nMics - 1;j++) {
		for (k = 0; k < length;k++) {
			output[k + (j + 1) * length] = input[j + 12 * k] * 0.00003052f;
		}
	}
}
int main(){
	
	AlsaHandle record;
	VoiceHandle voiceHandle;	
	voiceInit(&voiceHandle);	
	record = alsaInit("plughw:1,0",1,12,16000,0);
	alsaStart(record);	
	char *buffer = (char *)malloc(1024 * 2 * 12);
	float *aec = (float *)malloc(1024 * 2 * 4);
	float *input = (float *)malloc(1024 * 12 * 4);
	short *output = (short *)malloc(1024 * 2);
	int doadir[4];
	FILE *fp = fopen("aftervoice.pcm","wb");	
	while(1){
		alsaRead(record,buffer,2048 * 12);
		micShortToFloat((short *)buffer,input,aec,12,1024);
		voiceProcess(voiceHandle,input,output,aec,doadir);	
		fwrite((char *)output,1024 * 2,1,fp);
	}
}
