#define USC_ASR_SDK_APP_KEY "vov26jpwyzg4ayxec3qoklmtslev2m4a36ka7tac"
#define USC_ASR_SDK_SECRET_KEY "b818fb13ead37df1ef050c6060629b54"


/****	此处的帐号和密钥需要去官网申请后替换****************/
