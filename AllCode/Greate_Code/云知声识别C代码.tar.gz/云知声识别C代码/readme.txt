欢迎使用云知声 linux sdk
demo 目录为64位linux系统的样例，直接双击 ./run_sample.sh 即可进行服务。(如果没有权限，请添加 chmod +x run_sample.sh)服务原有音频文件位于 testfile 文件夹下，生成的文件也位于此文件夹下。
doc 目录为开发文档目录
libs 目录为语音识别、语义理解、语音合成所需要的动态库和头文件
sample 目录为开发工程样例
testfile 目录为测试样例目录