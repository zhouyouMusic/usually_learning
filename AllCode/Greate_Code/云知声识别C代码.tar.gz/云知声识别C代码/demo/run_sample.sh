./sample  ../testfile/ans.txt ../testfile/utf8.txt
