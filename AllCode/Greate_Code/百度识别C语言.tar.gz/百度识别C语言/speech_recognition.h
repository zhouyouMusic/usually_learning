#ifdef _SPEECH_RECONGNITION_H
#define _SPEECH_RECONGNITION_H



















#endif
