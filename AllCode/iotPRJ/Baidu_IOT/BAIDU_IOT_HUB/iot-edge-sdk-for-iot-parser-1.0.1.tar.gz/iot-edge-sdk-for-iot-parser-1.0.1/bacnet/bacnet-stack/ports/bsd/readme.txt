This is a port to MAC OS X for testing.
The unit tests can be run via the test.sh script.
