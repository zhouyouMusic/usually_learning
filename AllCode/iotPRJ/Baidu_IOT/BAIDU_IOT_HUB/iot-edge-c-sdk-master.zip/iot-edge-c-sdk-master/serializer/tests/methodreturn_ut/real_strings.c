// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#define COMPILING_REAL_STRINGS_C

#define GBALLOC_H
#include "real_strings.h"
#include "strings.c"
